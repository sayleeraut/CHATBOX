document.getElementById("send-button").addEventListener("click", function() {
    const userInput = document.getElementById("user-input").value.trim();
    const chatBox = document.getElementById("chat-box");

    // Ensure user input is not empty
    if (userInput === "") return;

    // Display user message
    chatBox.innerHTML += `<div class="user-message">${userInput}</div>`;
    document.getElementById("user-input").value = ""; // Clear input
    chatBox.scrollTop = chatBox.scrollHeight; // Scroll to the bottom

    // Bot response logic
    let botResponse = getBotResponse(userInput.toLowerCase());
    setTimeout(() => {
        chatBox.innerHTML += `<div class="bot-message">${botResponse}</div>`;
        chatBox.scrollTop = chatBox.scrollHeight; // Scroll to the bottom
    }, 500); // Simulate a slight delay for the bot's response
});

function getBotResponse(userInput) {
    if (userInput.includes("restaurant timings")) {
        return "The operating hours for the restaurant are: Monday - Friday: 11:00 AM - 10:00 PM, Saturday - Sunday: 12:00 PM - 11:00 PM.";
    } else if (userInput.includes("track my food order")) {
        return "To track your food order, go to 'My Orders' in the app and select your order. You'll see a map showing the delivery partner's location.";
    } else if (userInput.includes("apply coupon codes")) {
        return "To apply coupon codes, add items to your cart, go to checkout, and enter the coupon code at the bottom of the screen.";
    } else if (userInput.includes("report an issue")) {
        return "To report an issue, open the app, go to 'My Orders,' select your order, click 'Help,' and choose the specific problem.";
    } else {
        return "Sorry, I didn't understand that. Can you please ask something else?";
    }
}
